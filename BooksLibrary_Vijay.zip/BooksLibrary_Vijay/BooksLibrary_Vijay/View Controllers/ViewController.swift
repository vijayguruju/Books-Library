//
//  ViewController.swift
//  BooksLibrary_Vijay
//
//  Created by Dinesh Sunder on 20/04/19.
//  Copyright © 2019 vijay. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    

    @IBOutlet weak var tableView: UITableView!
    
    var dataArray = [String]()
    var resultData = [[String:Any]]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Register tableview cell with Reuseidentifier
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "CellID")
        
        //Fetch the required data from existing Json file
        getData()
        
    }

    //Get data from Json file
    func getData(){
        
        if let path = Bundle.main.path(forResource: "sample", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as! [[String:Any]]
                
                resultData = jsonResult
                // Fetching only Genre,Author name and Country to show in home screen
                var authors = [String]()
                var genres = [String]()
                var countries = [String]()
                for json in jsonResult{
                    
                    if let author = json["author_name"] as? String {
                        print("*****",author)
                        authors.append(author)
                    }
                    if let genre = json["genre"] as? String {
                        print("*****",genre)
                        genres.append(genre)
                    }
                    if let country = json["author_country"] as? String{
                    countries.append(country)
                    }
                }
                //Remove the duplicate values fromn obtained Arrays
                authors = authors.removingDuplicates()
                print("Authors are ",authors)
                genres = genres.removingDuplicates()
                print("Genres are ",genres)
                countries = countries.removingDuplicates()
                print("Countries are ",countries)
                
                //Add all arrays(Autors,Genres,Countries) into main Array to show in table view
                dataArray = authors + genres + countries
                print(dataArray)
            } catch {
                //  error
                print("Error")
            }
        }
        
        
        
    }
    
    //MARK:TableView methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath) as UITableViewCell
        cell.textLabel?.text = (dataArray[indexPath.row] )
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let value = dataArray[indexPath.row]
        var key = String()
        
        //fetch the key using selected value
        for dict in resultData{
            
            let reqDict  = dict.filter {$0.value as? String == value}
            
            if (reqDict.count > 0){
                key = reqDict.keys.first!
            }
        }
        // Now filter the data using selected value, respected key and assign into a new array
        let filterdData = resultData.filter{($0[key] as! String) == value}
        
        print(filterdData)
        //Navigate to next screen on click, i.e books details screen
        let DetailsVc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
            DetailsVc.inputData = filterdData as [[String : AnyObject]]
            self.navigationController?.pushViewController(DetailsVc, animated: true)
        
        //Hide selection
        tableView.deselectRow(at: indexPath, animated: true)
    }

}

//MARK: Extention
// extension to remove duplicates values from array
extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var addedDict = [Element: Bool]()
        
        return filter {
            addedDict.updateValue(true, forKey: $0) == nil
        }
    }
    
    mutating func removeDuplicates() {
        self = self.removingDuplicates()
    }
}

