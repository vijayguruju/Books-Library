//
//  DetailsViewController.swift
//  BooksLibrary_Vijay
//
//  Created by Dinesh Sunder on 20/04/19.
//  Copyright © 2019 vijay. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchResultsUpdating {
  

    @IBOutlet weak var tableView: UITableView!
    
    var inputData = [[String:AnyObject]]()
    var resultSearchController = UISearchController()
    var filteredTableData = [[String:AnyObject]]()

    override func viewDidLoad() {
        super.viewDidLoad()

        //Register custom cell with cell Id
        tableView.register(UINib(nibName: "DetailTableViewCell", bundle: nil), forCellReuseIdentifier: "Cell")
        
        //create a search controller with delegate add search bar at tableview header
        resultSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.sizeToFit()
            //Make search bar rounded corner
            if let textfield = controller.searchBar.value(forKey: "searchField") as? UITextField {
                if let backgroundview = textfield.subviews.first {
                    // Background color
                    backgroundview.backgroundColor = UIColor.white
                    // Rounded corner
                    backgroundview.layer.cornerRadius = 18;
                    backgroundview.clipsToBounds = true;
                }
            }
            tableView.tableHeaderView = controller.searchBar
            
            return controller
        })()
        self.definesPresentationContext = true
        resultSearchController.hidesNavigationBarDuringPresentation = false
    }
    
    
    //MARK:- TableView methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // check for searching is in progress or not, if it is get count from fileterd array otherwise get from input array from previous screen
        if  (resultSearchController.isActive) {
            return filteredTableData.count
        } else {
            return inputData.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100 //height as per our requirement
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DetailTableViewCell
        
        //Configure the custom cell with data
        configureCell(cell: cell, indexPath: indexPath)
        
        return cell
    }
    
    // Get the data and papulate it in the cell
    func configureCell(cell:DetailTableViewCell, indexPath:IndexPath){
        
        // check for searching is in progress or not, if it is get data from fileterd array otherwise get from input array from previous screen
        if (resultSearchController.isActive) {
            cell.titleLabel.text = (self.filteredTableData[indexPath.row]["book_title"] as! String)
            cell.authorsLabel.text = (self.filteredTableData[indexPath.row]["author_name"] as! String)
            cell.genreLabel.text = (self.filteredTableData[indexPath.row]["genre"] as! String)
            
            let url = URL(string: (self.filteredTableData[indexPath.row]["image_url"] as! String))
            
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: url!)
                if let imageData = data {
                    DispatchQueue.main.async {
                        cell.imgView.image = UIImage(data: imageData)
                    }
                }
            }

        }else{
        
        cell.titleLabel.text = (self.inputData[indexPath.row]["book_title"] as! String)
        cell.authorsLabel.text = (self.inputData[indexPath.row]["author_name"] as! String)
        cell.genreLabel.text = (self.inputData[indexPath.row]["genre"] as! String)
        
        let url = URL(string: (self.inputData[indexPath.row]["image_url"] as! String))
        DispatchQueue.global().async {
    
    
        let data = try? Data(contentsOf: url!)
        
        if let imageData = data {
            DispatchQueue.main.async {
                
            cell.imgView.image = UIImage(data: imageData)
            }
        }
        }
        }
    }
   
    //MARK:- SearchController Method
    func updateSearchResults(for searchController: UISearchController) {
        //remove previous data first to search
        filteredTableData.removeAll(keepingCapacity: false)
        //if the search is empty then show the data as it is
        if searchController.searchBar.text == nil || searchController.searchBar.text == ""{
            
            if(resultSearchController.isActive){
                
                filteredTableData = inputData
            }
            //Reload the TableView
            tableView.reloadData()
        }else{
            
            //Loop into input data to get the required matches and then filter with search text
            for dicData in self.inputData {
            let genreMatching : NSString = dicData["genre"] as! NSString
            let authorMatching : NSString = dicData["author_name"] as! NSString
            let titleMatching : NSString = dicData["book_title"] as! NSString
                
            let filter = (genreMatching.lowercased.range(of: searchController.searchBar.text!, options: NSString.CompareOptions.caseInsensitive, range: nil,locale: nil) != nil) || (authorMatching.lowercased.range(of: searchController.searchBar.text!, options: NSString.CompareOptions.caseInsensitive, range: nil,locale: nil) != nil) || (titleMatching.lowercased.range(of: searchController.searchBar.text!, options: NSString.CompareOptions.caseInsensitive, range: nil,locale: nil) != nil)
                if filter {
                filteredTableData.append(dicData)
                }
            }
            //Reload the TableView with filtered data
            self.tableView.reloadData()
        }
    }
    
    
    
}
